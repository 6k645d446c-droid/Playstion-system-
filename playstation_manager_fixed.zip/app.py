from flask import Flask, render_template, request, jsonify
import sqlite3, os, time
from datetime import datetime

app = Flask(__name__)
DB = os.path.join(os.path.dirname(__file__), "playstation.db")

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS devices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        single_price REAL NOT NULL DEFAULT 30,
        multi_price REAL NOT NULL DEFAULT 40
    );
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        price REAL NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        device_id INTEGER NOT NULL,
        mode TEXT NOT NULL DEFAULT 'single',
        started_at REAL NOT NULL,
        paused_at REAL,
        paused_seconds REAL NOT NULL DEFAULT 0,
        ended_at REAL,
        status TEXT NOT NULL DEFAULT 'running',
        FOREIGN KEY(device_id) REFERENCES devices(id)
    );
    CREATE TABLE IF NOT EXISTS session_products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        price REAL NOT NULL,
        qty INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS adjustments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        note TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS day_settings (
        id INTEGER PRIMARY KEY CHECK (id=1),
        started_at REAL,
        ended_at REAL
    );
    INSERT OR IGNORE INTO day_settings(id) VALUES (1);
    """)
    con.commit()
    con.close()

def session_data(row, con):
    if not row:
        return None
    now = time.time()
    end = row["ended_at"] or now
    paused = row["paused_seconds"] or 0
    if row["status"] == "paused" and row["paused_at"]:
        paused += now - row["paused_at"]
    elapsed = max(0, end - row["started_at"] - paused)
    dev = con.execute("SELECT * FROM devices WHERE id=?", (row["device_id"],)).fetchone()
    price = dev["single_price"] if row["mode"] == "single" else dev["multi_price"]
    play_cost = elapsed / 3600 * price
    products = con.execute("SELECT * FROM session_products WHERE session_id=?", (row["id"],)).fetchall()
    products_total = sum(p["price"] * p["qty"] for p in products)
    adjustments = con.execute("SELECT * FROM adjustments WHERE session_id=?", (row["id"],)).fetchall()
    adjustments_total = sum(a["amount"] for a in adjustments)
    return {
        "id": row["id"], "device_id": row["device_id"], "mode": row["mode"],
        "status": row["status"], "started_at": row["started_at"],
        "elapsed": int(elapsed), "price": price,
        "play_cost": play_cost, "products_total": products_total,
        "adjustments_total": adjustments_total,
        "total": play_cost + products_total + adjustments_total,
        "products": [dict(p) for p in products],
        "adjustments": [dict(a) for a in adjustments]
    }

@app.get("/api/health")
def health():
    return jsonify({"ok": True, "message": "PlayStation Manager is running"})

@app.route("/")
def index():
    return render_template("index.html")

@app.get("/api/state")
def state():
    con = db()
    devices = [dict(x) for x in con.execute("SELECT * FROM devices ORDER BY id")]
    products = [dict(x) for x in con.execute("SELECT * FROM products ORDER BY id")]
    sessions = {}
    for r in con.execute("SELECT * FROM sessions WHERE status IN ('running','paused')"):
        sessions[str(r["device_id"])] = session_data(r, con)
    day = con.execute("SELECT * FROM day_settings WHERE id=1").fetchone()
    con.close()
    return jsonify({"devices": devices, "products": products, "sessions": sessions, "day": dict(day)})

@app.post("/api/devices")
def add_device():
    data = request.json
    con = db()
    cur = con.execute("INSERT INTO devices(name,single_price,multi_price) VALUES(?,?,?)",
                      (data["name"], data.get("single_price",30), data.get("multi_price",40)))
    con.commit()
    item = dict(con.execute("SELECT * FROM devices WHERE id=?", (cur.lastrowid,)).fetchone())
    con.close()
    return jsonify(item)

@app.put("/api/devices/<int:did>")
def edit_device(did):
    data = request.json
    con = db()
    con.execute("UPDATE devices SET name=?,single_price=?,multi_price=? WHERE id=?",
                (data["name"], data["single_price"], data["multi_price"], did))
    con.commit(); con.close()
    return jsonify({"ok": True})

@app.delete("/api/devices/<int:did>")
def delete_device(did):
    con = db()
    active = con.execute("SELECT 1 FROM sessions WHERE device_id=? AND status IN ('running','paused')", (did,)).fetchone()
    if active:
        con.close()
        return jsonify({"error":"لا يمكن حذف جهاز عليه جلسة مفتوحة"}), 400
    con.execute("DELETE FROM devices WHERE id=?", (did,))
    con.commit(); con.close()
    return jsonify({"ok": True})

@app.post("/api/products")
def add_product():
    data = request.json
    con = db()
    cur = con.execute("INSERT INTO products(name,price) VALUES(?,?)", (data["name"], data["price"]))
    con.commit()
    item = dict(con.execute("SELECT * FROM products WHERE id=?", (cur.lastrowid,)).fetchone())
    con.close()
    return jsonify(item)

@app.put("/api/products/<int:pid>")
def edit_product(pid):
    data = request.json
    con = db()
    con.execute("UPDATE products SET name=?,price=? WHERE id=?", (data["name"],data["price"],pid))
    con.commit(); con.close()
    return jsonify({"ok":True})

@app.delete("/api/products/<int:pid>")
def delete_product(pid):
    con = db()
    con.execute("DELETE FROM products WHERE id=?", (pid,))
    con.commit(); con.close()
    return jsonify({"ok":True})

@app.post("/api/sessions/start")
def start_session():
    data = request.json
    con = db()
    active = con.execute("SELECT 1 FROM sessions WHERE device_id=? AND status IN ('running','paused')", (data["device_id"],)).fetchone()
    if active:
        con.close(); return jsonify({"error":"الجهاز عليه جلسة بالفعل"}),400
    cur = con.execute("INSERT INTO sessions(device_id,mode,started_at,status) VALUES(?,?,?,?)",
                      (data["device_id"],data.get("mode","single"),time.time(),"running"))
    con.commit(); con.close()
    return jsonify({"id":cur.lastrowid})

@app.post("/api/sessions/<int:sid>/pause")
def pause_session(sid):
    con=db()
    r=con.execute("SELECT * FROM sessions WHERE id=?", (sid,)).fetchone()
    if not r or r["status"]!="running":
        con.close(); return jsonify({"error":"الجلسة ليست قيد التشغيل"}),400
    con.execute("UPDATE sessions SET status='paused',paused_at=? WHERE id=?", (time.time(),sid))
    con.commit(); con.close(); return jsonify({"ok":True})

@app.post("/api/sessions/<int:sid>/resume")
def resume_session(sid):
    con=db()
    r=con.execute("SELECT * FROM sessions WHERE id=?", (sid,)).fetchone()
    if not r or r["status"]!="paused":
        con.close(); return jsonify({"error":"الجلسة ليست متوقفة مؤقتاً"}),400
    extra=time.time()-r["paused_at"]
    con.execute("UPDATE sessions SET status='running',paused_at=NULL,paused_seconds=paused_seconds+? WHERE id=?", (extra,sid))
    con.commit(); con.close(); return jsonify({"ok":True})

@app.post("/api/sessions/<int:sid>/product")
def add_session_product(sid):
    data=request.json
    con=db()
    p=con.execute("SELECT * FROM products WHERE id=?", (data["product_id"],)).fetchone()
    if not p:
        con.close(); return jsonify({"error":"المنتج غير موجود"}),404
    con.execute("INSERT INTO session_products(session_id,product_id,name,price,qty) VALUES(?,?,?,?,?)",
                (sid,p["id"],p["name"],p["price"],data.get("qty",1)))
    con.commit(); con.close(); return jsonify({"ok":True})

@app.post("/api/sessions/<int:sid>/adjustment")
def adjustment(sid):
    data=request.json
    con=db()
    con.execute("INSERT INTO adjustments(session_id,amount,note) VALUES(?,?,?)",
                (sid,float(data["amount"]),data.get("note","")))
    con.commit(); con.close(); return jsonify({"ok":True})

@app.post("/api/sessions/<int:sid>/end")
def end_session(sid):
    con=db()
    r=con.execute("SELECT * FROM sessions WHERE id=?", (sid,)).fetchone()
    if not r:
        con.close(); return jsonify({"error":"الجلسة غير موجودة"}),404
    now=time.time()
    if r["status"]=="paused" and r["paused_at"]:
        paused_extra=now-r["paused_at"]
        con.execute("UPDATE sessions SET paused_seconds=paused_seconds+?,paused_at=NULL WHERE id=?", (paused_extra,sid))
    con.execute("UPDATE sessions SET status='ended',ended_at=? WHERE id=?", (now,sid))
    con.commit()
    result=session_data(con.execute("SELECT * FROM sessions WHERE id=?", (sid,)).fetchone(),con)
    con.close()
    return jsonify(result)

@app.post("/api/day/start")
def day_start():
    con=db(); now=time.time()
    con.execute("UPDATE day_settings SET started_at=?,ended_at=NULL WHERE id=1",(now,))
    con.commit(); con.close(); return jsonify({"ok":True,"started_at":now})

@app.post("/api/day/end")
def day_end():
    con=db(); now=time.time()
    con.execute("UPDATE day_settings SET ended_at=? WHERE id=1",(now,))
    con.commit(); con.close(); return jsonify({"ok":True,"ended_at":now})

@app.get("/api/report")
def report():
    con=db()
    day=con.execute("SELECT * FROM day_settings WHERE id=1").fetchone()
    start=day["started_at"] or 0
    end=day["ended_at"] or time.time()
    rows=con.execute("SELECT * FROM sessions WHERE status='ended' AND started_at>=? AND started_at<=?",(start,end)).fetchall()
    total_play=total_products=total_adj=0
    by_device={}
    for r in rows:
        s=session_data(r,con)
        total_play+=s["play_cost"]; total_products+=s["products_total"]; total_adj+=s["adjustments_total"]
        key=str(r["device_id"])
        by_device.setdefault(key,{"device_id":r["device_id"],"sessions":0,"seconds":0,"total":0})
        by_device[key]["sessions"]+=1; by_device[key]["seconds"]+=s["elapsed"]; by_device[key]["total"]+=s["total"]
    con.close()
    return jsonify({"start":start,"end":end,"sessions":len(rows),"play":total_play,"products":total_products,
                    "adjustments":total_adj,"total":total_play+total_products+total_adj,"devices":list(by_device.values())})

if __name__=="__main__":
    init_db()
    app.run(host="0.0.0.0",port=5000,debug=False)
