let state={};

async function api(url,opts={}){
  try{
    let r=await fetch(url,{headers:{'Content-Type':'application/json',...(opts.headers||{})},...opts});
    let text=await r.text();
    let d={};
    try{d=JSON.parse(text)}catch(_){d={error:text||'استجابة غير صالحة من السيرفر'};}
    if(!r.ok) throw new Error(d.error||`خطأ HTTP ${r.status}`);
    return d;
  }catch(e){
    console.error(e);
    throw e;
  }
}
const money=n=>Number(n||0).toFixed(2)+' ج';
const fmt=s=>{s=Math.max(0,Math.floor(s||0));let h=Math.floor(s/3600),m=Math.floor(s%3600/60),sec=s%60;return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`};

async function load(){state=await api('/api/state');renderDevices();renderProducts()}
function renderDevices(){
 let el=document.getElementById('devices');
 el.innerHTML=state.devices.map(d=>{
   let s=state.sessions[String(d.id)], busy=!!s;
   return `<article class="card ${busy?'busy':'free'}">
   <div class="status">${busy?'🟢 مشغول':'🔴 فاضي'}</div>
   <h2>${esc(d.name)}</h2>
   ${busy?`<div>النمط: ${s.mode==='single'?'Single':'Multi'}</div><div>الوقت: <b id="timer-${d.id}">${fmt(s.elapsed)}</b></div><div>الحساب الحالي: <b id="total-${d.id}">${money(s.total)}</b></div>
   <div class="row"><button onclick="pauseResume(${s.id},'${s.status}')">${s.status==='running'?'⏸ إيقاف مؤقت':'▶ استكمال'}</button><button onclick="endSession(${s.id})">⏹ إنهاء</button></div>
   <div class="row"><button onclick="addProduct(${s.id})">🥤 منتج</button><button onclick="adjust(${s.id})">＋/− مبلغ</button></div>`
   :`<div>Single: ${money(d.single_price)} / ساعة</div><div>Multi: ${money(d.multi_price)} / ساعة</div>
   <div class="row"><button onclick="start(${d.id},'single')">▶ Single</button><button onclick="start(${d.id},'multi')">▶ Multi</button></div>
   <div class="row"><button class="secondary" onclick="editDevice(${d.id})">✏️ تعديل</button><button class="secondary" onclick="deleteDevice(${d.id})">🗑 حذف</button></div>`}
   </article>`
 }).join('');
}
function renderProducts(){document.getElementById('productsList').innerHTML=state.products.map(p=>`<div class="product-line"><span>${esc(p.name)} — ${money(p.price)}</span><span><button onclick="editProduct(${p.id})">تعديل</button> <button onclick="deleteProduct(${p.id})">حذف</button></span></div>`).join('')||'<p>لا توجد منتجات.</p>'}
function openModal(html){document.getElementById('modalContent').innerHTML=html;document.getElementById('modal').classList.remove('hidden')}
function closeModal(){document.getElementById('modal').classList.add('hidden')}
function openDeviceModal(d=null){openModal(`<h2>${d?'تعديل جهاز':'إضافة جهاز'}</h2><label>اسم الجهاز</label><input id="dn" value="${d?esc(d.name):''}"><label>سعر Single / ساعة</label><input id="ds" type="number" value="${d?d.single_price:30}"><label>سعر Multi / ساعة</label><input id="dm" type="number" value="${d?d.multi_price:40}"><br><br><button onclick="${d?`saveDevice(${d.id})`:'saveDevice()'}">حفظ</button>`)}
async function saveDevice(id){
  let name=document.getElementById('dn').value.trim();
  if(!name){alert('اكتب اسم الجهاز أولاً');return}
  let data={name,single_price:+document.getElementById('ds').value,multi_price:+document.getElementById('dm').value};
  try{await api(id?`/api/devices/${id}`:'/api/devices',{method:id?'PUT':'POST',body:JSON.stringify(data)});closeModal();await load();alert(id?'تم تعديل الجهاز بنجاح':'تمت إضافة الجهاز بنجاح')}
  catch(e){alert('تعذر حفظ الجهاز: '+e.message)}
}
function editDevice(id){openDeviceModal(state.devices.find(x=>x.id===id))}
async function deleteDevice(id){if(confirm('حذف الجهاز؟')){try{await api('/api/devices/'+id,{method:'DELETE'});load()}catch(e){alert(e.message)}}}
function openProductModal(p=null){openModal(`<h2>${p?'تعديل منتج':'إضافة منتج'}</h2><label>اسم المنتج</label><input id="pn" value="${p?esc(p.name):''}"><label>السعر</label><input id="pp" type="number" value="${p?p.price:0}"><br><br><button onclick="${p?`saveProduct(${p.id})`:'saveProduct()'}">حفظ</button>`)}
async function saveProduct(id){
  let name=document.getElementById('pn').value.trim();
  if(!name){alert('اكتب اسم المنتج أولاً');return}
  let data={name,price:+document.getElementById('pp').value};
  try{await api(id?`/api/products/${id}`:'/api/products',{method:id?'PUT':'POST',body:JSON.stringify(data)});closeModal();await load();alert(id?'تم تعديل المنتج بنجاح':'تمت إضافة المنتج بنجاح')}
  catch(e){alert('تعذر حفظ المنتج: '+e.message)}
}
function editProduct(id){openProductModal(state.products.find(x=>x.id===id))}
async function deleteProduct(id){if(confirm('حذف المنتج؟')){await api('/api/products/'+id,{method:'DELETE'});load()}}
async function start(device_id,mode){try{await api('/api/sessions/start',{method:'POST',body:JSON.stringify({device_id,mode})});load()}catch(e){alert(e.message)}}
async function pauseResume(id,status){await api('/api/sessions/'+id+'/'+(status==='running'?'pause':'resume'),{method:'POST'});load()}
async function endSession(id){if(confirm('إنهاء الجلسة؟')){let r=await api('/api/sessions/'+id+'/end',{method:'POST'});alert('الإجمالي النهائي: '+money(r.total));load()}}
function addProduct(sid){openModal(`<h2>إضافة منتج للجلسة</h2><select id="prod">${state.products.map(p=>`<option value="${p.id}">${esc(p.name)} — ${money(p.price)}</option>`).join('')}</select><label>الكمية</label><input id="qty" type="number" value="1" min="1"><br><br><button onclick="saveSessionProduct(${sid})">إضافة</button>`)}
async function saveSessionProduct(sid){await api('/api/sessions/'+sid+'/product',{method:'POST',body:JSON.stringify({product_id:+document.getElementById('prod').value,qty:+document.getElementById('qty').value})});closeModal();load()}
function adjust(sid){openModal(`<h2>إضافة / خصم</h2><p>اكتب قيمة موجبة للإضافة أو سالبة للخصم.</p><input id="adj" type="number" step="0.01" placeholder="-10 أو 20"><label>ملاحظة اختيارية</label><input id="note"><br><br><button onclick="saveAdjustment(${sid})">حفظ</button>`)}
async function saveAdjustment(sid){await api('/api/sessions/'+sid+'/adjustment',{method:'POST',body:JSON.stringify({amount:+document.getElementById('adj').value,note:document.getElementById('note').value})});closeModal();load()}
async function dayStart(){await api('/api/day/start',{method:'POST'});alert('تم تسجيل بداية اليوم')}
async function dayEnd(){await api('/api/day/end',{method:'POST'});alert('تم تسجيل نهاية اليوم');showReport()}
async function showProducts(){document.getElementById('productsPanel').classList.toggle('hidden');document.getElementById('reportPanel').classList.add('hidden')}
async function showReport(){document.getElementById('reportPanel').classList.toggle('hidden');document.getElementById('productsPanel').classList.add('hidden');let r=await api('/api/report');document.getElementById('report').innerHTML=`<div class="report-grid"><div class="stat">دخل الأجهزة<b>${money(r.play)}</b></div><div class="stat">المنتجات<b>${money(r.products)}</b></div><div class="stat">إضافات/خصومات<b>${money(r.adjustments)}</b></div><div class="stat">الإجمالي<b>${money(r.total)}</b></div><div class="stat">عدد الجلسات<b>${r.sessions}</b></div></div><h3>ملخص الأجهزة</h3>${r.devices.map(x=>`<p>جهاز ${x.device_id}: ${x.sessions} جلسة — ${fmt(x.seconds)} — ${money(x.total)}</p>`).join('')||'<p>لا توجد جلسات مغلقة في الفترة الحالية.</p>'}`}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
setInterval(()=>{document.getElementById('clock').textContent=new Date().toLocaleString('ar-EG');for(let k in state.sessions){let s=state.sessions[k];if(s.status==='running'){s.elapsed++;let t=document.getElementById('timer-'+k);if(t)t.textContent=fmt(s.elapsed);let d=state.devices.find(x=>x.id==k);let price=s.mode==='single'?d.single_price:d.multi_price;let total=s.elapsed/3600*price+s.products_total+s.adjustments_total;let el=document.getElementById('total-'+k);if(el)el.textContent=money(total)}}},1000);
load();
